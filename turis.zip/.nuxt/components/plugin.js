import Vue from 'vue'
import { wrapFunctional } from './index'

const components = {
  SectionsBrands: () => import('../..\\components\\sections\\Brands.vue' /* webpackChunkName: "components/sections-brands" */).then(c => wrapFunctional(c.default || c)),
  SectionsCalloutBlock: () => import('../..\\components\\sections\\CalloutBlock.vue' /* webpackChunkName: "components/sections-callout-block" */).then(c => wrapFunctional(c.default || c)),
  SectionsContactForm: () => import('../..\\components\\sections\\contactForm.vue' /* webpackChunkName: "components/sections-contact-form" */).then(c => wrapFunctional(c.default || c)),
  SectionsFeatures: () => import('../..\\components\\sections\\Features.vue' /* webpackChunkName: "components/sections-features" */).then(c => wrapFunctional(c.default || c)),
  SectionsFooterContactForm: () => import('../..\\components\\sections\\footerContactForm.vue' /* webpackChunkName: "components/sections-footer-contact-form" */).then(c => wrapFunctional(c.default || c)),
  SectionsHero: () => import('../..\\components\\sections\\Hero.vue' /* webpackChunkName: "components/sections-hero" */).then(c => wrapFunctional(c.default || c)),
  SectionsHeroAlt: () => import('../..\\components\\sections\\HeroAlt.vue' /* webpackChunkName: "components/sections-hero-alt" */).then(c => wrapFunctional(c.default || c)),
  SectionsIntro: () => import('../..\\components\\sections\\Intro.vue' /* webpackChunkName: "components/sections-intro" */).then(c => wrapFunctional(c.default || c)),
  SectionsPricing: () => import('../..\\components\\sections\\Pricing.vue' /* webpackChunkName: "components/sections-pricing" */).then(c => wrapFunctional(c.default || c)),
  SectionsTeam: () => import('../..\\components\\sections\\Team.vue' /* webpackChunkName: "components/sections-team" */).then(c => wrapFunctional(c.default || c)),
  SectionsTestimonials: () => import('../..\\components\\sections\\Testimonials.vue' /* webpackChunkName: "components/sections-testimonials" */).then(c => wrapFunctional(c.default || c)),
  SectionsTimeline: () => import('../..\\components\\sections\\Timeline.vue' /* webpackChunkName: "components/sections-timeline" */).then(c => wrapFunctional(c.default || c)),
  FooterTop: () => import('../..\\components\\footerTop.vue' /* webpackChunkName: "components/footer-top" */).then(c => wrapFunctional(c.default || c)),
  Logo: () => import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c)),
  Notification: () => import('../..\\components\\Notification.vue' /* webpackChunkName: "components/notification" */).then(c => wrapFunctional(c.default || c)),
  SiteFooter: () => import('../..\\components\\siteFooter.vue' /* webpackChunkName: "components/site-footer" */).then(c => wrapFunctional(c.default || c)),
  SiteHeader: () => import('../..\\components\\siteHeader.vue' /* webpackChunkName: "components/site-header" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
