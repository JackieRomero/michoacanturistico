<template>
  <section id="home">
    <v-row no-gutters>
      <v-col cols="12">
        <SectionsHero />
        <SectionsIntro />
        <SectionsCalloutBlock />

        <SectionsTestimonials />
      </v-col>
    </v-row>
  </section>
</template>
