<template>
  <nuxt />
</template>
